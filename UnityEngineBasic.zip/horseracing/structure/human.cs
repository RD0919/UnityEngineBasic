﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace structure
{
    internal class human
    {
        //클래스의 멤버 구조체변수는 
        //힙영역의 클래스 타입 객체에 같이 할당된다.
        public Stats stats;
    }
}
