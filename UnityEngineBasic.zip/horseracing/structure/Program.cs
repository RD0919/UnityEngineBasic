﻿using structure;

human Human = new human();

Human.stats = new Stats();

Human.stats = new Stats(1, 2, 3, 4);

Human.stats.STR = 1;
