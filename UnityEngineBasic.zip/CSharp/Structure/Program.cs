﻿using Structure;

Human human = new Human();

human.stats = new Stats();

human.stats = new Stats(1, 2, 3, 4);

human.stats.STR = 1;