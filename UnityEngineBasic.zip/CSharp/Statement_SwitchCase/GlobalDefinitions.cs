﻿// enum 키워드
// 열거형 사용자 정의 자료형을 정의할때 쓰는 키워드
// 4byte 정수형.
enum CharacterTypes
{
    None, // or Nothing or Idle
    가렌 = 10,
    나서스,
    다리우스,
    바루스,
    제드
}