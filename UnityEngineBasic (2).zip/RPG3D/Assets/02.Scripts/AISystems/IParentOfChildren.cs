﻿using System.Collections.Generic;

public interface IParentOfChildren
{
    List<Node> children { get; set; }
}
