﻿
public interface IParentOfChild
{
    Node child { get; set; }
}
